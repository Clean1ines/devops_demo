--
-- PostgreSQL database dump
--

\restrict 9mqBRVkRDaOFlfsBOvHpykeVH6iJ9CfasvEQ0kWKDwpdFA2djD3xEuzI7qlQdbg

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: equipment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.equipment (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    model character varying(100),
    serial_number character varying(100),
    object_id integer,
    last_maintenance timestamp with time zone,
    status character varying(50) DEFAULT 'operational'::character varying,
    parameters jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT equipment_status_check CHECK (((status)::text = ANY ((ARRAY['operational'::character varying, 'maintenance'::character varying, 'faulty'::character varying, 'decommissioned'::character varying])::text[])))
);


ALTER TABLE public.equipment OWNER TO postgres;

--
-- Name: equipment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.equipment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.equipment_id_seq OWNER TO postgres;

--
-- Name: equipment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.equipment_id_seq OWNED BY public.equipment.id;


--
-- Name: industrial_objects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.industrial_objects (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(100),
    location character varying(500),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT industrial_objects_type_check CHECK (((type)::text = ANY ((ARRAY['АЭС'::character varying, 'ТЭЦ'::character varying, 'ГЭС'::character varying, 'Завод'::character varying, 'Рудник'::character varying])::text[])))
);


ALTER TABLE public.industrial_objects OWNER TO postgres;

--
-- Name: industrial_objects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.industrial_objects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.industrial_objects_id_seq OWNER TO postgres;

--
-- Name: industrial_objects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.industrial_objects_id_seq OWNED BY public.industrial_objects.id;


--
-- Name: equipment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment ALTER COLUMN id SET DEFAULT nextval('public.equipment_id_seq'::regclass);


--
-- Name: industrial_objects id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.industrial_objects ALTER COLUMN id SET DEFAULT nextval('public.industrial_objects_id_seq'::regclass);


--
-- Data for Name: equipment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.equipment (id, name, model, serial_number, object_id, last_maintenance, status, parameters, created_at) FROM stdin;
1	Турбина Т-250	Т-250/300-240	TURB-001-2023	1	2024-01-15 00:00:00+00	operational	\N	2025-12-05 13:29:35.071859+00
2	Генератор ГСВ-1500	ГСВ-1500/20	GEN-002-2023	1	2024-02-20 00:00:00+00	operational	\N	2025-12-05 13:29:35.071859+00
3	Реактор ВВЭР-1200	ВВЭР-1200	REACT-001-2022	3	2024-03-10 00:00:00+00	maintenance	\N	2025-12-05 13:29:35.071859+00
4	Трансформатор ТДЦ-400	ТДЦ-400000/330	TRANS-005-2021	2	2024-01-30 00:00:00+00	operational	\N	2025-12-05 13:29:35.071859+00
\.


--
-- Data for Name: industrial_objects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.industrial_objects (id, name, type, location, created_at, updated_at) FROM stdin;
1	Белоярская АЭС	АЭС	Свердловская область, г. Заречный	2025-12-05 13:29:35.067256+00	2025-12-05 13:29:35.067256+00
2	Сургутская ГРЭС-2	ТЭЦ	ХМАО-Югра, г. Сургут	2025-12-05 13:29:35.067256+00	2025-12-05 13:29:35.067256+00
3	Нововоронежская АЭС	АЭС	Воронежская область	2025-12-05 13:29:35.067256+00	2025-12-05 13:29:35.067256+00
4	Красноярский алюминиевый завод	Завод	Красноярский край	2025-12-05 13:29:35.067256+00	2025-12-05 13:29:35.067256+00
\.


--
-- Name: equipment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.equipment_id_seq', 4, true);


--
-- Name: industrial_objects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.industrial_objects_id_seq', 4, true);


--
-- Name: equipment equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_pkey PRIMARY KEY (id);


--
-- Name: equipment equipment_serial_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_serial_number_key UNIQUE (serial_number);


--
-- Name: industrial_objects industrial_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.industrial_objects
    ADD CONSTRAINT industrial_objects_pkey PRIMARY KEY (id);


--
-- Name: idx_equipment_object_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_equipment_object_id ON public.equipment USING btree (object_id);


--
-- Name: idx_equipment_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_equipment_status ON public.equipment USING btree (status);


--
-- Name: idx_objects_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_objects_type ON public.industrial_objects USING btree (type);


--
-- Name: industrial_objects update_objects_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON public.industrial_objects FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: equipment equipment_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_object_id_fkey FOREIGN KEY (object_id) REFERENCES public.industrial_objects(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO app_user;


--
-- Name: TABLE equipment; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.equipment TO app_user;


--
-- Name: SEQUENCE equipment_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.equipment_id_seq TO app_user;


--
-- Name: TABLE industrial_objects; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.industrial_objects TO app_user;


--
-- Name: SEQUENCE industrial_objects_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.industrial_objects_id_seq TO app_user;


--
-- PostgreSQL database dump complete
--

\unrestrict 9mqBRVkRDaOFlfsBOvHpykeVH6iJ9CfasvEQ0kWKDwpdFA2djD3xEuzI7qlQdbg

